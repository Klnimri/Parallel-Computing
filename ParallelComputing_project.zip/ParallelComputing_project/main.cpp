#include <omp.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <chrono>

bool is_prime(int num) {
    if (num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 == 0 || num % 3 == 0) return false;
    for (int i = 5; i * i <= num; i += 6) {
        if (num % i == 0 || num % (i + 2) == 0)
            return false;
    }
    return true;
}

std::vector<int> parallel_prime_factors(long long N, int num_threads) {
    std::vector<int> factors;
    #pragma omp parallel for num_threads(num_threads) schedule(dynamic)
    for (int i = 1; i <= std::sqrt(N); ++i) {
        if (N % i == 0) {
            if (is_prime(i))
                #pragma omp critical
                factors.push_back(i);
            long long complement = N / i;
            if (complement != i && is_prime(complement))
                #pragma omp critical
                factors.push_back(complement);
        }
    }
    return factors;
}

int main() {
    std::vector<long long> numbers = {1234567890, 23423456780, 234780234562, 5067891002343};
    std::vector<int> thread_counts = {4, 8, 16};

    for (auto N : numbers) {
        std::cout << "Number: " << N << std::endl;
        for (auto threads : thread_counts) {
            auto start_time = std::chrono::high_resolution_clock::now();
            std::vector<int> factors = parallel_prime_factors(N, threads);
            auto end_time = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double, std::milli> exec_time = end_time - start_time;

            std::cout << "Threads: " << threads << ", Execution Time: " << exec_time.count() << " ms, Factors: ";
            for (int factor : factors)
                std::cout << factor << " ";
            std::cout << std::endl;
        }
    }

    return 0;
}
