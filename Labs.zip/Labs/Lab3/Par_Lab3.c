#include <stdio.h>
#include <math.h>

// Function to calculate f(x)
double f(double x) {
    return exp(x); // e^x
}

// Function to compute the area under the curve using the trapezoidal rule
double trap(double a, double b, int n) {
    double h = (b - a) / n; // width of each trapezoid
    double sum = 0.5 * (f(a) + f(b)); // area of first and last trapezoids

    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        sum += f(x);
    }

    return sum * h; // total area
}

int main() {
    double a, b;
    int n;

    // Input values of a, b, and n
    printf("Enter the lower limit (a): ");
    scanf("%lf", &a);
    printf("Enter the upper limit (b): ");
    scanf("%lf", &b);
    printf("Enter the number of trapezoids (n): ");
    scanf("%d", &n);

    // Calculate and display the area under the curve
    double area = trap(a, b, n);
    printf("Area under the curve: %lf\n", area);

    return 0;
}
